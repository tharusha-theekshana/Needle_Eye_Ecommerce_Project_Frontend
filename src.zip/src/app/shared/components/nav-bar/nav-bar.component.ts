import { Component } from '@angular/core';
import {APP_CONFIG} from '../../../core/config/app.config';
import {NgForOf, NgIf} from '@angular/common';
import {Router, RouterLink} from '@angular/router';

@Component({
  selector: 'app-nav-bar',
  imports: [
    NgIf,
    RouterLink,
    NgForOf
  ],
  standalone: true,
  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.css'
})
export class NavBarComponent {
  brandName = APP_CONFIG.brand.name;
  navLinks = APP_CONFIG.nav.links;
  cartCount = 3;
  isLogged = true;

  constructor(private router: Router){}

  goLogin() {
    this.router.navigate(['/login']);
  }
}
