import { Component } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {TextInputComponent} from '../../../../shared/components/text-input/text-input.component';
import {APP_CONFIG} from '../../../../core/config/app.config';
import {Router, RouterLink} from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [
    ReactiveFormsModule,
    TextInputComponent,
    FormsModule,
    RouterLink
  ],
  standalone : true,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  brandName = APP_CONFIG.brand.name;
  currentYear: number = new Date().getFullYear();

  email = '';
  password = '';

  emailError = '';
  passwordError = '';

  submitting = false;

  constructor(private router: Router) {}

  onSubmit() {
    this.emailError = '';
    this.passwordError = '';

    if (!this.email) {
      this.emailError = 'Email is required';
    } else if (!this.email.includes('@')) {
      this.emailError = 'Enter a valid email';
    }

    if (!this.password) {
      this.passwordError = 'Password is required';
    } else if (this.password.length < 6) {
      this.passwordError = 'Minimum 6 characters';
    }

    if (this.emailError || this.passwordError) {
      return;
    }

    this.submitting = true;
    console.log(this.email);

  }
}
